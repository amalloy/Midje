(defproject semi-sweet-simple "1.0.0"
  :description "An example of using Midje semi-sweet mocking"
  :dependencies [[org.clojure/clojure "[1.1.0,1.2.0]"]
                 [org.clojure/clojure-contrib "[1.1.0,1.2.0]"]
		 [midje "0.8.1"]
		 ]
)

